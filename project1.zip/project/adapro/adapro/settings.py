INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'Minerpro',  # Your app name here
]
# settings.py
EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
EMAIL_HOST = 'smtp.gmail.com'
EMAIL_PORT = 587
EMAIL_USE_TLS = True
EMAIL_HOST_USER = 'manishcpu394@gmail.com'
EMAIL_HOST_PASSWORD = 'Manish@123'  # <- NOT your Gmail password!



LOGIN_REDIRECT_URL = '/'
LOGOUT_REDIRECT_URL = '/login/'

# Add templates dir if needed
import os
from pathlib import Path
BASE_DIR = Path(__file__).resolve().parent.parent
TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [os.path.join(BASE_DIR, 'Minerpro', 'templates')],  # or 'Minerpro/templates' if that's your actual folder
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]
EMAIL_HOST_USER = os.getenv('EMAIL_USER')
EMAIL_HOST_PASSWORD = os.getenv('EMAIL_PASS')


TEMPLATES[0]['DIRS'] = [os.path.join(BASE_DIR, 'Minerpro/templates')]
MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',  
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware', 
    'django.contrib.messages.middleware.MessageMiddleware',    
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',  # Use SQLite database
        'NAME': BASE_DIR / 'db.sqlite3',         # Path to your SQLite database file
    }
}
ROOT_URLCONF = 'adapro.urls' 
STATIC_URL = '/static/'
STATICFILES_DIRS = [
    BASE_DIR / "static",  # make sure a static/ folder exists
]
ALLOWED_HOSTS = ['*']
DEBUG = True
APPEND_SLASH = False
SECRET_KEY = '%x(f_n6nzp72w&x)=o*tu9iy*263cdfc3=a*q=%ylv9f-#tjtb'

