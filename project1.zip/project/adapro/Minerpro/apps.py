from django.apps import AppConfig


class MinerproConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Minerpro'
