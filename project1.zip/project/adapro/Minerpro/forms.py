from django import forms
from django.core.exceptions import ValidationError

GENDER_CHOICES = [
    ('male', 'Male'),
    ('female', 'Female'),
    ('other', 'Other'),
]

class RegistrationForm(forms.Form):
    fname = forms.CharField(label="First Name", max_length=50)
    lname = forms.CharField(label="Last Name", max_length=50)
    mobile = forms.CharField(label="Mobile Number", max_length=10)
    email = forms.EmailField(label="Email")
    gender = forms.ChoiceField(choices=GENDER_CHOICES, widget=forms.RadioSelect)
    dob = forms.DateField(label="Date of Birth", widget=forms.DateInput(attrs={'type': 'date'}))
    password = forms.CharField(label="Password", widget=forms.PasswordInput)
    repassword = forms.CharField(label="Re-enter Password", widget=forms.PasswordInput)

    def clean(self):
        cleaned_data = super().clean()
        password = cleaned_data.get("password")
        repassword = cleaned_data.get("repassword")

        if password != repassword:
            raise ValidationError("Passwords do not match.")
        
        return cleaned_data
