import random
from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm
from django.core.mail import send_mail  # Or use SMS API
from django.contrib import messages

def generate_otp():
    return str(random.randint(100000, 999999))

def register(request):
    if request.method == 'POST':
        # Collect form data
        request.session['user_data'] = {
            'fname': request.POST['fname'],
            'lname': request.POST['lname'],
            'mobile': request.POST['mobile'],
            'email': request.POST['email'],
            'gender': request.POST['gender'],
            'dob': request.POST['dob'],
            'password': request.POST['password'],
        }

        # Generate and send OTP
        otp = generate_otp()
        request.session['otp'] = otp

        # For now, send OTP via email for demo
        send_mail(
            'Your OTP Code',
            f'Your OTP is {otp}',
            'from@example.com',
            [request.POST['email']],
        )
        return redirect('otp_verify')

    return render(request, 'register.html')

def verify_otp(request):
    if request.method == 'POST':
        entered_otp = request.POST.get('otp')
        if entered_otp == request.session.get('otp'):
            user_data = request.session.get('user_data')
            # TODO: Save user_data to DB
            del request.session['otp']
            del request.session['user_data']
            messages.success(request, "Registration successful!")
            return redirect('/')
        else:
            messages.error(request, "Invalid OTP.")
    
    return render(request, 'otp_verify.html')

def index(request):
    return render(request, 'index.html')

def login_view(request):
    return render(request, 'login.html')
